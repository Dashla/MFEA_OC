%% Calling the solvers
% For large population sizes, consider using the Parallel Computing Toolbox
% of MATLAB.
% Else, program can be slow.
pop_M=200; % population size 100
pop_S = pop_M;
gen=1000; % generation count 1000
selection_pressure = 'elitist'; % choose either 'elitist' or 'roulette wheel'
p_il = 0; % probability of individual learning (BFGA quasi-Newton Algorithm) --> Indiviudal Learning is an IMPORTANT component of the MFEA.
rmp=0.5; % random mating probability
reps = 1; % repetitions 20
for index = 1:1
    Tasks = benchmark(index);
    data_MFEA(index)=MFEA_OC(Tasks,pop_M,gen,selection_pressure,reps);   
end

save('Task10_MFEA_OC.mat','data_MFEA');

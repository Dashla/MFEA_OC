function [flag,t1,E] = Calculate_entropy(population,generation,t,rep,E)
    subpop1 = find([population.skill_factor] == 1);
    subpop2 = find([population.skill_factor] == 2);
    num1 = length(subpop1);
    num2 = length(subpop2);
    number = min(fix(num1/2),fix(num2/2));
    n1 = randperm(num1,number);
    n2 = randperm(num2,number);
    pop1_Angle = zeros(1,number*(number - 1));
    pop2_Angle = zeros(1,number*(number - 1));
    for i = 1 : number
        for j = 2:number
            d1 = population(subpop1(n1(i)));
            d2 = population(subpop1(n1(j)));
            c1 = dot(d1.rnvec,d2.rnvec)/(norm(d1.rnvec)*norm(d2.rnvec));
            d3 = population(subpop2(n2(i)));
            d4 = population(subpop2(n2(j)));
            c2 = dot(d3.rnvec,d4.rnvec)/(norm(d3.rnvec)*norm(d4.rnvec));
            pop1_Angle(1,i * (j-1)) = acos(c1);
            pop2_Angle(1,i * (j-1)) = acos(c2);
        end
    end
    g = [abs(pop1_Angle),abs(pop2_Angle)];
    e = entropy(g);
    E(rep,generation) = e;
    flag = 0;
    t1 = t;
    if generation > 5
        sumrize = sum(E(1,generation-4:generation));
        if sumrize > 5 * e
            flag = 1;
        else
            flag = 2;
            t1 = t * rand();
        end
    end    
end
clc
clear

pop_M=200; % population size for multitasking   
gen=500; % generation count 
selection_pressure = 'elitist'; % choose either 'elitist' or 'roulette wheel'
p_il = 0; % probability of individua1l learning (BFGA quasi-Newton Algorithm) - local search (optional)
reps = 1; % reps > 1 to compute mean rmp values

for index=1:9
    Tasks = benchmark(index);
    data_MFEA_OC(index)=MFEA_OC(Tasks,pop_M,gen,selection_pressure,p_il,reps);
end
save('Task9_MFEA_OC.mat','data_MFEA_OC');
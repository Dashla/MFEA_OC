clc
clear

pop_M=200; % population size for multitasking   
gen=500; % generation count 
selection_pressure = 'elitist'; % choose either 'elitist' or 'roulette wheel'
p_il = 0; % probability of individua1l learning (BFGA quasi-Newton Algorithm) - local search (optional)
reps = 1; % reps > 1 to compute mean rmp values
%加记录参数
maxFEs = 200000;
numRecords = 100;
%加记录参数

for index=1:10
    Tasks = benchmark(index);
    data_MFEA_OC(index)=MFEA_OC(Tasks,pop_M,gen,selection_pressure,reps);
end
save('Task10_MFEA_OC.mat','data_MFEA_OC');